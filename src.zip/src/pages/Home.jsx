import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { products } from '../data/products';
import '../styles/Home.css';

const Home = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);

  // Get one featured product for each category
  const featuredKeyboard = products.find(p => p.category === 'keyboards');
  const featuredMouse = products.find(p => p.category === 'mice');
  const featuredHeadphones = products.find(p => p.category === 'headphones');
  const featuredAccessories = products.find(p => p.category === 'accessories');

  const featuredProducts = {
    keyboard: {
      ...featuredKeyboard,
      description: "Trải nghiệm cảm giác gõ phím cơ học đỉnh cao với độ phản hồi siêu nhạy và đèn LED RGB rực rỡ.",
      features: ["Switch hotswap cao cấp", "Pin dung lượng lớn", "Kết nối 3 chế độ"]
    },
    mouse: {
      ...featuredMouse,
      description: "Thiết kế siêu nhẹ kết hợp với cảm biến quang học chính xác nhất thế giới cho mọi cú click hoàn hảo.",
      features: ["Cảm biến 26K DPI", "Trọng lượng siêu nhẹ", "Switch quang học"]
    },
    headphone: {
      ...featuredHeadphones,
      description: "Công nghệ âm thanh vòm sống động giúp bạn nghe rõ mọi bước chân đối thủ trong trận chiến.",
      features: ["Âm thanh vòm 7.1", "Micro khử tiếng ồn", "Đệm tai memory foam"]
    },
    accessory: {
      ...featuredAccessories,
      description: "Hoàn thiện góc gaming của bạn với những phụ kiện chất lượng cao giúp tối ưu hóa không gian chơi game.",
      features: ["Thiết kế công thái học", "Chất liệu cao cấp", "Tương thích đa thiết bị"]
    }
  };

  return (
    <div className="minimal-home">
      {/* HERO SECTION */}
      <section className="home-hero-minimal">
        <div className="container">
          <div className="hero-grid">
            <div className="hero-text-side">
              <span className="premium-tagline">Collection you'll love</span>
              <h1>SCYTOL GEAR</h1>
              <p className="hero-subtitle">
                Nâng tầm trải nghiệm gaming với hệ sinh thái thiết bị ngoại vi SCYTOL cao cấp nhất hiện nay. 
                Hiệu năng đỉnh cao kết hợp với thiết kế tối giản tinh tế.
              </p>
              <Link to="/keyboards" className="hero-cta">KHÁM PHÁ NGAY</Link>
            </div>
            <div className="hero-image-side">
              <img src={featuredProducts.keyboard.image} alt="SCYTOL Flagship" />
            </div>
          </div>
        </div>
      </section>

      {/* BRAND INTRO */}
      <section className="brand-intro-section section-white">
        <div className="container brand-intro-container">
          <div className="brand-intro-image">
            <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=1200" alt="SCYTOL Legacy" />
          </div>
          <div className="brand-intro-text">
            <span className="premium-tagline">Our Philosophy</span>
            <h2>Vũ khí tối thượng của bạn</h2>
            <p>
              SCYTOL không chỉ mang đến thiết bị, chúng tôi xây dựng hệ sinh thái giúp bạn làm chủ mọi cuộc chơi. 
              Mỗi sản phẩm là sự kết giao giữa kỹ thuật chính xác và nghệ thuật thiết kế.
            </p>
            <div className="brand-features">
              <div className="feature-item">
                <div className="feature-icon">⚡</div>
                <h3>Apex Performance</h3>
                <p>Công nghệ không dây độ trễ siêu thấp.</p>
              </div>
              <div className="feature-item">
                <div className="feature-icon">💎</div>
                <h3>Craftsmanship</h3>
                <p>Vật liệu cao cấp và hoàn thiện tỉ mỉ.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SHOWCASES */}
      <section className="showcase-section section-blue">
        <div className="container showcase-container">
          <div className="showcase-image-side">
            <img src={featuredProducts.keyboard.image} alt={featuredProducts.keyboard.name} />
          </div>
          <div className="showcase-info-side">
            <div className="premium-showcase-card">
              <span className="category-tag">Mechanical Keyboards</span>
              <h2 className="product-showcase-name">{featuredProducts.keyboard.name}</h2>
              <p className="product-showcase-desc">{featuredProducts.keyboard.description}</p>
              <ul className="feature-bullets">
                {featuredProducts.keyboard.features.map((f, i) => (
                  <li key={i}><span className="bullet-dot"></span> {f}</li>
                ))}
              </ul>
              <div className="showcase-price">{featuredProducts.keyboard.price?.toLocaleString('vi-VN')} ₫</div>
              <Link to="/keyboards" className="view-more-showcase">SHOP KEYBOARDS</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="showcase-section section-white">
        <div className="container showcase-container">
          <div className="showcase-image-side">
            <img src={featuredProducts.mouse.image} alt={featuredProducts.mouse.name} />
          </div>
          <div className="showcase-info-side">
            <div className="premium-showcase-card">
              <span className="category-tag">Gaming Mice</span>
              <h2 className="product-showcase-name">{featuredProducts.mouse.name}</h2>
              <p className="product-showcase-desc">{featuredProducts.mouse.description}</p>
              <ul className="feature-bullets">
                {featuredProducts.mouse.features.map((f, i) => (
                  <li key={i}><span className="bullet-dot"></span> {f}</li>
                ))}
              </ul>
              <div className="showcase-price">{featuredProducts.mouse.price?.toLocaleString('vi-VN')} ₫</div>
              <Link to="/mice" className="view-more-showcase">SHOP MICE</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="showcase-section section-purple">
        <div className="container showcase-container">
          <div className="showcase-image-side">
            <img src={featuredProducts.headphone.image} alt={featuredProducts.headphone.name} />
          </div>
          <div className="showcase-info-side">
            <div className="premium-showcase-card">
              <span className="category-tag">Audio Series</span>
              <h2 className="product-showcase-name">{featuredProducts.headphone.name}</h2>
              <p className="product-showcase-desc">{featuredProducts.headphone.description}</p>
              <ul className="feature-bullets">
                {featuredProducts.headphone.features.map((f, i) => (
                  <li key={i}><span className="bullet-dot"></span> {f}</li>
                ))}
              </ul>
              <div className="showcase-price">{featuredProducts.headphone.price?.toLocaleString('vi-VN')} ₫</div>
              <Link to="/headphones" className="view-more-showcase">SHOP AUDIO</Link>
            </div>
          </div>
        </div>
      </section>

      {/* CHAT SUPPORT */}
      <div className={`chat-widget ${isChatOpen ? 'open' : ''}`}>
        <div className="chat-widget-header">
          <span>Hỗ trợ trực tuyến</span>
          <button type="button" className="chat-close-btn" onClick={() => setIsChatOpen(false)}>×</button>
        </div>
        <div className="chat-widget-body">
          <p className="chat-greeting">Xin chào! Chúng tôi có thể giúp gì cho bạn? 👋</p>
          <div className="chat-quick-actions">
            <button className="chat-pill">Thông tin giao hàng</button>
            <button className="chat-pill">Liên hệ hỗ trợ</button>
          </div>
        </div>
      </div>

      <button className="chat-toggle-button" onClick={() => setIsChatOpen(p => !p)}>
        <span className="chat-toggle-text">Chat</span>
      </button>
    </div>
  );
};

export default Home;
