import React from 'react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';
import '../styles/CategoryPage.css';

const Sale = () => {
  const saleProducts = products.filter(p => p.sale);

  return (
    <div className="all-products-page sale-theme">
      <header className="all-products-header">
        <div className="container">
          <h1>SPECIAL OFFERS</h1>
          <p>Cơ hội sở hữu các thiết bị SCYTOL với mức giá hấp dẫn nhất.</p>
        </div>
      </header>

      <section className="all-products-content section-white">
        <div className="container">
          <div className="products-grid">
            {saleProducts.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Sale;
